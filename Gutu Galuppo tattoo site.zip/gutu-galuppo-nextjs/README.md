# Gutu Galuppo — tattoo artist site

A single-page site for Berlin tattoo artist **Gutu Galuppo** (fine line, blackwork, ornamental). Built with **Next.js 14 (App Router)**, **TypeScript**, and **Tailwind CSS**. Booking inquiries first, portfolio second.

The governing idea: **the page is being tattooed.** Scrolling is the session; a fine needle line draws itself down the page as you scroll, writing the section titles and drawing three motifs (a rose, a chess compass, a mandala) between sections, with a glowing dot riding the drawing frontier.

## Getting started

```bash
npm install
npm run dev      # http://localhost:3000
```

Other scripts: `npm run build`, `npm run start`, `npm run lint`, `npm run typecheck`.

Requires Node 18.17+ (Next 14).

## Stack & conventions

- **Next 14 App Router**, `src/` directory, `@/*` path alias.
- **TypeScript strict** (plus `noUncheckedIndexedAccess`), no `any`.
- **Tailwind** for styling; design tokens live in `tailwind.config.ts` and the two CSS custom properties in `src/app/globals.css`.
- **No animation library.** All motion is plain React hooks + IntersectionObserver + CSS transforms/opacity, to keep the JS budget small and Lighthouse high. Every effect respects `prefers-reduced-motion`.
- **`next/image`** for every photo, with a shared blur placeholder and lazy loading.

## Project structure

```
src/
  app/
    layout.tsx        Metadata + OpenGraph, fonts (next/font), <LanguageProvider>
    page.tsx          Composes the sections + the needle overlay
    globals.css       Tailwind layers, base resets, --accent, grain texture
  context/
    LanguageProvider.tsx   EN / PT-BR / DE / ES switch (persisted to localStorage)
  hooks/
    useReducedMotion.ts    Live prefers-reduced-motion flag
    useInView.ts           Reveal-on-scroll IntersectionObserver primitive
  lib/
    types.ts               Shared types
    content.ts             Portfolio data, process steps, FAQ, form options, contacts
    i18n.ts                Message dictionaries (English source + 3 translations)
  components/
    motion/                *** all motion logic is isolated here ***
      NeedleLine.tsx       The signature scroll-drawn line + dot + ornament drawing
      InkedHeading.tsx     Titles revealed by a left-to-right ink wipe led by a dot
      StencilImage.tsx     Portfolio images: stencil -> linework -> healed
      Parallax.tsx         Transform-only parallax layer (capped, reduced-motion safe)
      Ornament.tsx         Mounts a drawn motif on the needle path
      ornaments.ts         SVG builders for the rose / chess compass / mandala
    ui/
      Nav.tsx, InkButton.tsx, Lightbox.tsx, Grain.tsx
    sections/
      Hero, Portfolio, About, Process, Faq, Booking, Footer
```

### Tuning or removing motion

Every effect is a self-contained component or hook — tune or delete it without touching section code:

- **Needle line** — `NeedleLine.tsx`. The dot eases toward the scroll position (the `drawnLen += diff * 0.09` line controls how fast it "draws"). A Y→length lookup maps scroll position to the correct length along the weaving path, so the dot always sits at the true frontier and stays on screen. Remove `<NeedleLine>` from `page.tsx` to drop it entirely.
- **Inked headings** — `InkedHeading.tsx`. Reveals once on scroll-in. `onNeedle` marks a heading as a waypoint the line routes across (so it appears written).
- **Stencil images** — `StencilImage.tsx`. Three-stage heal (~1.2s) on intersection.
- **Parallax** — `Parallax.tsx`. `speed` prop, displacement capped at ~15% (8% on mobile).
- **Micro-interactions** — CTA ink-fill in `InkButton.tsx`; form underline draw in `Booking.tsx`.

All of them no-op under `prefers-reduced-motion` (content appears instantly; the needle renders as a static, fully-drawn line).

## Content & i18n

- Copy for every language lives in `src/lib/i18n.ts`. English is the source; PT-BR / DE / ES patch over it. Add a language by extending `LANGS` and adding a dictionary.
- Portfolio items, process steps, FAQ, and contact details are data in `src/lib/content.ts`.

## Images (drop-in)

Placeholders come from `placehold.co`; the first tile and the hero use the artist's real reference image at `public/portfolio/made-in-brasil.png`. To go live, drop real files into `public/` and update the `src` paths — see `public/README.md`. Once nothing loads from placehold.co, remove its entry from `next.config.mjs`.

## Booking form

Client-side validation with inline error states (name, email, idea required; email format checked). On submit it composes a pre-filled **mailto:** to `galuppodev@gmail.com` — no backend. To capture inquiries server-side instead, replace the `mailto` block in `Booking.tsx` with a POST to your API route or form service. Reference-image upload is described in copy (attach in the mail client); wire a real upload if you add a backend.

## Accessibility

Semantic landmarks, labelled controls, ARIA on the FAQ accordion and the lightbox dialog, visible focus rings, alt text on every image, and full reduced-motion support.

## Where this came from

Recreated from an HTML design prototype. The prototype is a visual/behavioral reference — this repo is the production implementation.
