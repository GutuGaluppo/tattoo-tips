import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // near-black ground / off-white ink, one deep-red accent
        bg: "#0a0a0a",
        panel: "#131211",
        stone: "#141312",
        ink: {
          DEFAULT: "#ece7df",
          soft: "rgba(236,231,223,0.78)",
          mute: "rgba(236,231,223,0.55)",
          faint: "rgba(236,231,223,0.4)",
          line: "rgba(236,231,223,0.1)",
        },
        accent: {
          // static hex so Tailwind opacity modifiers (bg-accent/20) work.
          // The runtime-tunable line color is the CSS var --accent (globals.css),
          // kept equal to this — change both together if you retint.
          DEFAULT: "#8e1c1c",
          bright: "#c94040",
          dot: "#e05a5a",
          error: "#d05050",
        },
      },
      fontFamily: {
        // wired up by next/font in layout.tsx
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      letterSpacing: {
        kicker: "0.34em",
        label: "0.24em",
        wide: "0.2em",
      },
      transitionTimingFunction: {
        ink: "cubic-bezier(0.65,0,0.3,1)",
      },
      keyframes: {
        grain: {
          "0%,100%": { transform: "translate(0,0)" },
          "12%": { transform: "translate(-2%,-3%)" },
          "25%": { transform: "translate(1.5%,-1%)" },
          "37%": { transform: "translate(-1%,2.5%)" },
          "50%": { transform: "translate(2.5%,1%)" },
          "62%": { transform: "translate(-2.5%,0.5%)" },
          "75%": { transform: "translate(1%,-2.5%)" },
          "87%": { transform: "translate(-1.5%,1.5%)" },
        },
      },
      animation: {
        grain: "grain 9s steps(10) infinite",
      },
    },
  },
  plugins: [],
};

export default config;
