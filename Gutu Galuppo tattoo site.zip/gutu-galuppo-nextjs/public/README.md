# /public assets

Drop real images here — they are referenced by path so swaps need no code changes.

## What's expected

| Path | Used by | Notes |
| --- | --- | --- |
| `portfolio/made-in-brasil.png` | Hero background + first portfolio tile | Ships with the artist's real reference image. |
| `portfolio/<id>.jpg` | Portfolio grid | One file per item id in `src/lib/content.ts` (e.g. `carranca.jpg`). Until you add them, those tiles load from placehold.co. After adding, change each item's `src` to `/portfolio/<id>.jpg` and remove the placehold.co entry from `next.config.mjs`. |
| `og.jpg` | Open Graph / Twitter card | 1200×630. Referenced in `src/app/layout.tsx`. Add one for good Instagram/social sharing. |
| `favicon.ico` | Browser tab | Optional. Next also supports `src/app/icon.png`. |

## Portrait

The About portrait currently loads from placehold.co (see `src/components/sections/About.tsx`).
Drop `portrait.jpg` here and point the `<Image src>` at `/portrait.jpg`.
