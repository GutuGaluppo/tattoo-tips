"use client";

import { useEffect, useRef, useState } from "react";

interface Options {
  /** fraction of the element visible before it counts as "in view" */
  threshold?: number;
  /** shrink the viewport from the bottom so reveals fire a touch early */
  rootMargin?: string;
  /** fire only the first time it enters (default true) */
  once?: boolean;
}

/**
 * Reveal-on-scroll primitive. Returns a ref to attach and a boolean that flips
 * true when the element scrolls into view. Falls back to `true` immediately if
 * IntersectionObserver is unavailable.
 */
export function useInView<T extends HTMLElement>({
  threshold = 0.25,
  rootMargin = "0px 0px -10% 0px",
  once = true,
}: Options = {}): [React.RefObject<T>, boolean] {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setInView(true);
            if (once) io.unobserve(entry.target);
          } else if (!once) {
            setInView(false);
          }
        }
      },
      { threshold, rootMargin },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, rootMargin, once]);

  return [ref, inView];
}
