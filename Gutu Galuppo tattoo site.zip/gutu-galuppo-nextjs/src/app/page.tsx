"use client";

import { useRef } from "react";
import { Nav } from "@/components/ui/Nav";
import { Grain } from "@/components/ui/Grain";
import { NeedleLine } from "@/components/motion/NeedleLine";
import { Ornament } from "@/components/motion/Ornament";
import { Hero } from "@/components/sections/Hero";
import { Portfolio } from "@/components/sections/Portfolio";
import { About } from "@/components/sections/About";
import { Process } from "@/components/sections/Process";
import { Faq } from "@/components/sections/Faq";
import { Booking } from "@/components/sections/Booking";
import { Footer } from "@/components/sections/Footer";

export default function Home() {
  const pageRef = useRef<HTMLDivElement>(null);

  return (
    <>
      <Nav />
      <Grain />
      <main ref={pageRef} className="relative overflow-clip bg-bg">
        {/* the needle line overlays the whole page and stitches it together */}
        <NeedleLine containerRef={pageRef} />

        <Hero />
        <Portfolio />
        <Ornament kind="rose" />
        <About />
        <Ornament kind="chess" />
        <Process />
        <Ornament kind="mandala" />
        <Faq />
        <Booking />
        <Footer />
      </main>
    </>
  );
}
