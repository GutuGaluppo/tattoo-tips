import type { Metadata, Viewport } from "next";
import { Pirata_One, Archivo } from "next/font/google";
import { LanguageProvider } from "@/context/LanguageProvider";
import "./globals.css";

const display = Pirata_One({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const sans = Archivo({
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const SITE_URL = "https://gutugaluppo.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "Gutu Galuppo — Tattoo Artist in Berlin",
  description:
    "Fine line, blackwork and ornamental tattoos in Berlin. Brazilian artist Gutu Galuppo translates drawings into skin — book a session.",
  keywords: ["tattoo", "Berlin", "fine line", "blackwork", "ornamental", "Gutu Galuppo", "Brazilian tattoo artist"],
  authors: [{ name: "Gutu Galuppo" }],
  openGraph: {
    type: "website",
    url: SITE_URL,
    title: "Gutu Galuppo — Tattoo Artist in Berlin",
    description: "Fine line · Blackwork · Ornamental. Drawings translated into skin — one line at a time.",
    siteName: "Gutu Galuppo",
    images: [{ url: "/og.jpg", width: 1200, height: 630, alt: "Gutu Galuppo — tattoo artist in Berlin" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Gutu Galuppo — Tattoo Artist in Berlin",
    description: "Fine line · Blackwork · Ornamental. Drawings translated into skin.",
    images: ["/og.jpg"],
  },
  alternates: { canonical: SITE_URL },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="font-sans">
        <LanguageProvider>{children}</LanguageProvider>
      </body>
    </html>
  );
}
