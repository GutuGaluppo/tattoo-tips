"use client";

import { type ReactNode } from "react";

type Variant = "solid-border" | "ghost";
type Size = "md" | "lg";

interface CommonProps {
  children: ReactNode;
  variant?: Variant;
  size?: Size;
  className?: string;
}

interface LinkProps extends CommonProps {
  href: string;
  target?: string;
  rel?: string;
  type?: never;
}
interface ButtonProps extends CommonProps {
  href?: never;
  type?: "button" | "submit";
  onClick?: () => void;
}

type InkButtonProps = LinkProps | ButtonProps;

/**
 * CTA whose ink fills from the bottom up on hover/focus — a color-pack pass.
 * The fill is a transform-scaled layer (composited, no paint), and the label
 * sits above it. Renders as <a> when given href, otherwise <button>.
 */
export function InkButton(props: InkButtonProps) {
  const { children, variant = "solid-border", size = "md", className = "" } = props;

  const pad = size === "lg" ? "px-9 py-4" : "px-5 py-2.5";
  const border = variant === "solid-border" ? "border-accent" : "border-ink/30";
  const fill = variant === "solid-border" ? "bg-accent" : "bg-ink/10";
  const textColor = variant === "solid-border" ? "text-ink" : "text-ink/85";

  const inner = (
    <>
      <span
        aria-hidden="true"
        className={`absolute inset-0 origin-bottom scale-y-0 transition-transform duration-[380ms] ease-ink group-hover:scale-y-100 group-focus-visible:scale-y-100 ${fill}`}
      />
      <span className="relative">{children}</span>
    </>
  );

  const shared = `group relative inline-flex items-center overflow-hidden border ${border} ${textColor} ${pad} text-[13px] uppercase tracking-wide ${className}`;

  if ("href" in props && props.href !== undefined) {
    return (
      <a href={props.href} target={props.target} rel={props.rel} className={shared}>
        {inner}
      </a>
    );
  }

  return (
    <button type={props.type ?? "button"} onClick={props.onClick} className={`${shared} cursor-pointer bg-transparent`}>
      {inner}
    </button>
  );
}
