"use client";

import { useLanguage } from "@/context/LanguageProvider";
import { LANGS, LANG_LABEL } from "@/lib/i18n";
import { InkButton } from "./InkButton";

const NAV_LINKS: { href: string; key: "navWork" | "navAbout" | "navProcess" | "navFaq" }[] = [
  { href: "#work", key: "navWork" },
  { href: "#about", key: "navAbout" },
  { href: "#process", key: "navProcess" },
  { href: "#faq", key: "navFaq" },
];

export function Nav() {
  const { t, lang, setLang } = useLanguage();

  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 top-0 z-50 flex flex-wrap items-center gap-x-[26px] gap-y-2.5 border-b border-ink/[0.08] bg-bg/[0.78] px-[clamp(20px,4vw,48px)] py-3 backdrop-blur-[10px]"
    >
      <a href="#top" className="font-display text-[26px] leading-none text-ink hover:text-ink">
        Gutu Galuppo
      </a>

      <div className="flex flex-wrap items-center gap-[22px] text-xs uppercase tracking-[0.18em]">
        {NAV_LINKS.map((l) => (
          <a key={l.href} href={l.href} className="text-ink/80 transition-colors hover:text-accent-bright">
            {t(l.key)}
          </a>
        ))}
      </div>

      <div className="ml-auto flex items-center gap-4">
        <div role="group" aria-label="Language" className="flex gap-0.5 text-[11px] tracking-[0.1em]">
          {LANGS.map((code) => {
            const on = code === lang;
            return (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                aria-pressed={on}
                className={`cursor-pointer border-b bg-transparent px-[7px] py-1.5 transition-colors ${
                  on ? "border-accent text-ink" : "border-transparent text-ink/45 hover:text-ink/80"
                }`}
              >
                {LANG_LABEL[code]}
              </button>
            );
          })}
        </div>

        <InkButton href="#book" className="text-[11px]">
          {t("cta")}
        </InkButton>
      </div>
    </nav>
  );
}
