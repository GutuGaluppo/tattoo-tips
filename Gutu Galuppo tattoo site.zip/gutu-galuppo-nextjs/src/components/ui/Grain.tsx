/**
 * Ambient film-grain overlay — the one thing on the page that loops. Fixed,
 * pointer-events-none, above content but below dialogs. Frozen under
 * prefers-reduced-motion (the animation is disabled via the media query).
 */
export function Grain() {
  return (
    <div
      aria-hidden="true"
      className="grain-overlay pointer-events-none fixed -inset-[130px] z-[100] opacity-[0.07] motion-safe:animate-grain"
    />
  );
}
