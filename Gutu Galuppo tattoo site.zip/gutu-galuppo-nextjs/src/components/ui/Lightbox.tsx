"use client";

import Image from "next/image";
import { useEffect } from "react";
import { BLUR_DATA_URL } from "@/lib/content";

export interface LightboxItem {
  src: string;
  alt: string;
  title: string;
  category: string;
  width: number;
  height: number;
}

interface LightboxProps {
  item: LightboxItem | null;
  onClose: () => void;
}

/**
 * Portfolio lightbox. Traps Escape, locks scroll while open, and restores
 * focus. ARIA dialog semantics; click backdrop or the close button to dismiss.
 */
export function Lightbox({ item, onClose }: LightboxProps) {
  useEffect(() => {
    if (!item) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [item, onClose]);

  if (!item) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      onClick={onClose}
      className="fixed inset-0 z-[90] flex cursor-zoom-out flex-col items-center justify-center bg-[rgba(6,5,5,.94)] px-[5vw] py-[5vh]"
    >
      <Image
        src={item.src}
        alt={item.alt}
        width={item.width}
        height={item.height}
        placeholder="blur"
        blurDataURL={BLUR_DATA_URL}
        className="max-h-[78vh] w-auto max-w-[92vw] object-contain shadow-[0_30px_80px_rgba(0,0,0,.65)]"
        onClick={(e) => e.stopPropagation()}
      />
      <div className="mt-[18px] flex items-baseline gap-4">
        <span className="font-display text-2xl text-ink">{item.title}</span>
        <span className="text-[11px] uppercase tracking-label text-ink/55">{item.category}</span>
      </div>
      <button
        type="button"
        onClick={onClose}
        aria-label="Close"
        className="absolute right-[22px] top-[18px] h-11 w-11 cursor-pointer border border-ink/30 bg-transparent text-xl text-ink"
      >
        &times;
      </button>
    </div>
  );
}
