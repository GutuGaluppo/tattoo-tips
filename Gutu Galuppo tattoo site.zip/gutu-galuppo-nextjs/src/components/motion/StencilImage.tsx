"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { useInView } from "@/hooks/useInView";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { BLUR_DATA_URL } from "@/lib/content";

interface StencilImageProps {
  src: string;
  alt: string;
  width: number;
  height: number;
  className?: string;
  /** e.g. { aspectRatio: "3 / 4" } to size the masonry cell */
  style?: React.CSSProperties;
  sizes?: string;
  priority?: boolean;
}

type Stage = "stencil" | "linework" | "healed";

/**
 * Portfolio image that heals as it enters the viewport, in three stages that
 * mirror a real tattoo: (a) stencil — desaturated, low opacity, purple transfer
 * tint; (b) linework — contrast ramps up; (c) healed — full colour. ~1.2s total.
 * Only opacity/filter transition (no layout), and it's skipped under
 * prefers-reduced-motion. next/image handles lazy-loading + blur placeholder.
 */
export function StencilImage({ src, alt, width, height, className = "", style, sizes, priority }: StencilImageProps) {
  const reduced = useReducedMotion();
  const [ref, inView] = useInView<HTMLDivElement>({ threshold: 0.22 });
  const [stage, setStage] = useState<Stage>("stencil");

  useEffect(() => {
    if (reduced) {
      setStage("healed");
      return;
    }
    if (!inView) return;
    setStage("linework");
    const t = window.setTimeout(() => setStage("healed"), 480);
    return () => window.clearTimeout(t);
  }, [inView, reduced]);

  const filter =
    stage === "stencil"
      ? "grayscale(1) sepia(.9) hue-rotate(205deg) saturate(1.4) brightness(.85) contrast(.8)"
      : stage === "linework"
        ? "grayscale(1) contrast(1.3) brightness(.95)"
        : "none";
  const opacity = stage === "stencil" ? 0.4 : stage === "linework" ? 0.9 : 1;

  return (
    <div ref={ref} className={`relative overflow-hidden bg-stone ${className}`} style={style}>
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        sizes={sizes}
        priority={priority}
        placeholder="blur"
        blurDataURL={BLUR_DATA_URL}
        className="h-full w-full object-cover"
        style={{
          filter,
          opacity,
          transition: reduced
            ? undefined
            : stage === "healed"
              ? "filter .7s ease, opacity .5s ease"
              : "filter .45s ease, opacity .4s ease",
        }}
      />
    </div>
  );
}
