"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface ParallaxProps {
  /**
   * Displacement factor. Positive moves slower than scroll (recedes), negative
   * moves faster (approaches). Kept small — the layer never travels more than
   * ~15% of its own height.
   */
  speed: number;
  className?: string;
  children: ReactNode;
}

/**
 * Transform-only parallax layer. Displacement is capped and the whole effect is
 * skipped under prefers-reduced-motion. Uses translate3d for a cheap composited
 * transform (no layout/paint), protecting Lighthouse scores.
 */
export function Parallax({ speed, className, children }: ParallaxProps) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el || reduced) return;

    const mobile = window.matchMedia("(max-width: 719px)").matches;
    const factor = mobile ? speed * 0.5 : speed;
    let raf = 0;

    const update = () => {
      raf = 0;
      const rect = el.getBoundingClientRect();
      const mid = rect.top + rect.height / 2 - window.innerHeight / 2;
      const cap = (mobile ? 0.08 : 0.15) * rect.height;
      let ty = -mid * factor;
      ty = Math.max(-cap, Math.min(cap, ty));
      el.style.transform = `translate3d(0, ${ty.toFixed(1)}px, 0)`;
    };

    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };

    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", update);
      if (raf) cancelAnimationFrame(raf);
      el.style.transform = "";
    };
  }, [speed, reduced]);

  return (
    <div ref={ref} className={className} style={{ willChange: reduced ? undefined : "transform" }}>
      {children}
    </div>
  );
}
