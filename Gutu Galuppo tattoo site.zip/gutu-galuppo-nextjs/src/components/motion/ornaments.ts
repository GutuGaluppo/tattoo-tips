import type { OrnamentKind } from "@/lib/types";

/**
 * Each builder returns an inline SVG string whose strokable paths carry a
 * `data-draw` attribute. NeedleLine measures those paths and reveals them with
 * stroke-dashoffset as the needle's dot passes through the ornament — so a rose,
 * a chess compass and a mandala appear to be drawn by the same needle that
 * stitches the page together.
 */
export function ornamentSVG(kind: OrnamentKind): string {
  if (kind === "mandala") return mandala();
  if (kind === "chess") return chess();
  return rose();
}

function rose(): string {
  return (
    '<svg viewBox="0 0 180 230" width="180" height="230" style="width:clamp(140px,22vw,190px);height:auto;overflow:visible" fill="none" stroke="var(--accent)" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" opacity="0.92">' +
    '<path data-draw d="M90 205 L90 150"/>' +
    '<path data-draw d="M90 168 C66 162 50 176 54 196 C78 196 92 182 90 168 Z"/>' +
    '<path data-draw d="M92 176 C116 170 132 184 128 204 C104 204 90 190 92 176 Z"/>' +
    '<path data-draw d="M40 92 C28 58 56 28 90 28 C124 28 152 58 140 92 C150 122 120 146 90 142 C60 146 30 122 40 92 Z"/>' +
    '<path data-draw d="M56 84 C52 58 74 44 90 44 C106 44 128 58 124 84 C128 104 108 120 90 118 C72 120 52 104 56 84 Z"/>' +
    '<path data-draw d="M96 106 C70 112 66 74 90 70 C110 66 108 92 92 96 C80 99 82 82 90 80"/>' +
    "</svg>"
  );
}

function mandala(): string {
  const cx = 130;
  const cy = 130;
  const P = (r: number, a: number): [string, string] => [
    (cx + r * Math.cos(a)).toFixed(1),
    (cy + r * Math.sin(a)).toFixed(1),
  ];
  let e = "";
  for (const r of [16, 34, 84]) e += `<circle data-draw cx="${cx}" cy="${cy}" r="${r}"/>`;
  const ring = (n: number, ri: number, ro: number, off: number): string => {
    let s = "";
    for (let i = 0; i < n; i++) {
      const a = off + (i / n) * 2 * Math.PI;
      const dw = (Math.PI / n) * 0.9;
      const [bx, by] = P(ri, a);
      const [tx, ty] = P(ro, a);
      const [c1x, c1y] = P((ri + ro) / 2, a - dw);
      const [c2x, c2y] = P((ri + ro) / 2, a + dw);
      s += `<path data-draw d="M${bx} ${by} Q${c1x} ${c1y} ${tx} ${ty} Q${c2x} ${c2y} ${bx} ${by} Z"/>`;
    }
    return s;
  };
  e += ring(12, 34, 62, 0);
  e += ring(16, 84, 106, Math.PI / 16);
  return `<svg viewBox="0 0 260 260" width="260" height="260" style="width:clamp(180px,30vw,230px);height:auto;overflow:visible" fill="none" stroke="var(--accent)" stroke-width="1.05" stroke-linecap="round" stroke-linejoin="round" opacity="0.9">${e}</svg>`;
}

function chess(): string {
  const cx = 110;
  const cy = 110;
  let e = `<circle data-draw cx="${cx}" cy="${cy}" r="100"/><circle data-draw cx="${cx}" cy="${cy}" r="82"/>`;
  const pieces = [pKing(), pQueen(), pBishop(), pKnight()];
  const R = 56;
  for (let i = 0; i < 4; i++) {
    const ang = -Math.PI / 2 + (i * Math.PI) / 2;
    const px = (cx + R * Math.cos(ang)).toFixed(1);
    const py = (cy + R * Math.sin(ang)).toFixed(1);
    // angled clockwise: king, queen, bishop, knight
    const deg = ((ang * 180) / Math.PI + 90 + 22).toFixed(1);
    e += `<g transform="translate(${px} ${py}) rotate(${deg})">${pieces[i]}</g>`;
  }
  return `<svg viewBox="0 0 220 220" width="220" height="220" style="width:clamp(170px,28vw,220px);height:auto;overflow:visible" fill="none" stroke="var(--accent)" stroke-width="1.15" stroke-linecap="round" stroke-linejoin="round" opacity="0.9">${e}</svg>`;
}

function pKing(): string {
  return '<path data-draw d="M0 -24 L0 -15 M-4 -20 L4 -20 M-7 -12 Q0 -17 7 -12 L9 6 L-9 6 Z M-12 13 L12 13 L9 6 M-12 13 L-9 6"/>';
}
function pQueen(): string {
  return '<path data-draw d="M0 -23 m-2.5 0 a2.5 2.5 0 1 0 5 0 a2.5 2.5 0 1 0 -5 0 M-10 -15 L-6 5 L6 5 L10 -15 L4 -5 L0 -15 L-4 -5 Z M-11 12 L11 12 L6 5 M-11 12 L-6 5"/>';
}
function pBishop(): string {
  return '<path data-draw d="M0 -25 m-2 0 a2 2 0 1 0 4 0 a2 2 0 1 0 -4 0 M0 -21 C-9 -13 -9 2 -7 6 L7 6 C9 2 9 -13 0 -21 Z M-1 -14 L4 -9 M-11 13 L11 13 L7 6 M-11 13 L-7 6"/>';
}
function pKnight(): string {
  return '<path data-draw d="M-8 6 L-9 -5 C-10 -17 3 -23 10 -18 C13 -16 10 -12 14 -11 C9 -8 9 -2 7 6 Z M-11 12 L11 12"/>';
}
