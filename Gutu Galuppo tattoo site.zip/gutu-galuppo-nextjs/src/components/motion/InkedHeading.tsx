"use client";

import { type ElementType, useEffect, useState } from "react";
import { useInView } from "@/hooks/useInView";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface InkedHeadingProps {
  children: string;
  /** heading level — defaults to h2 */
  as?: Extract<ElementType, "h1" | "h2" | "h3">;
  className?: string;
  /** id anchor for the section, if this heading titles one */
  id?: string;
  /**
   * When true, marks the heading as a waypoint on the needle's path so the line
   * routes across it (the needle "writes" the title). Section titles set this.
   */
  onNeedle?: boolean;
}

/**
 * A section title revealed as if being drawn: a left-to-right clip wipe led by a
 * small accent dot (the needle), with a 1–2px ink-bleed that sharpens as the
 * letters land. Fires once, on first scroll into view. Under
 * prefers-reduced-motion it renders instantly with no wipe.
 */
export function InkedHeading({ children, as = "h2", className = "", id, onNeedle = true }: InkedHeadingProps) {
  const reduced = useReducedMotion();
  const [ref, inView] = useInView<HTMLHeadingElement>({ threshold: 0.35 });
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    if (inView && !reduced) setRevealed(true);
  }, [inView, reduced]);

  const Tag = as;
  const active = revealed || reduced;

  return (
    <Tag
      ref={ref}
      id={id}
      data-ink=""
      {...(onNeedle ? { "data-needle": "" } : {})}
      className={`relative font-display font-normal text-ink ${className}`}
      style={{
        clipPath: reduced ? undefined : active ? "inset(-15% -6% -15% 0)" : "inset(-15% 100% -15% 0)",
        filter: reduced ? undefined : active ? "blur(0px)" : "blur(3px)",
        opacity: reduced ? 1 : active ? 1 : 0.35,
        transition: reduced
          ? undefined
          : "clip-path 1s cubic-bezier(.65,0,.3,1), filter .8s ease .2s, opacity .6s ease",
        scrollMarginTop: id ? 70 : undefined,
      }}
    >
      {children}
      {!reduced && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute top-1/2 h-[7px] w-[7px] rounded-full bg-accent"
          style={{
            left: active ? "101%" : "-6px",
            opacity: active ? 0 : 1,
            boxShadow: "0 0 12px 3px rgba(201,64,64,.7)",
            transition: "left 1s cubic-bezier(.65,0,.3,1), opacity .3s ease 1s",
          }}
        />
      )}
    </Tag>
  );
}
