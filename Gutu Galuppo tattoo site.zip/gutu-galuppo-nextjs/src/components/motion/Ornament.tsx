"use client";

import { useMemo } from "react";
import type { OrnamentKind } from "@/lib/types";
import { ornamentSVG } from "./ornaments";

/**
 * A drawn tattoo motif that sits between sections on the needle's path. It only
 * renders the (static) SVG — the drawing animation is owned by <NeedleLine>,
 * which finds the `data-draw` paths and reveals them as its dot passes through.
 */
export function Ornament({ kind }: { kind: OrnamentKind }) {
  const html = useMemo(() => ornamentSVG(kind), [kind]);
  return (
    <div
      data-ornament={kind}
      aria-hidden="true"
      className="relative z-[1] flex items-center justify-center px-5 py-6"
      style={{ minHeight: MIN_HEIGHT[kind] }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

const MIN_HEIGHT: Record<OrnamentKind, number> = {
  rose: 300,
  chess: 320,
  mandala: 340,
};
