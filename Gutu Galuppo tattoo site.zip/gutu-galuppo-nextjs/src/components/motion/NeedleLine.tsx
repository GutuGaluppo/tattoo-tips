"use client";

import { useEffect, useRef, type RefObject } from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface NeedleLineProps {
  /** the relatively-positioned page wrapper this SVG overlays */
  containerRef: RefObject<HTMLElement>;
}

interface Anchor {
  orn: boolean;
  ink: boolean;
  l: number;
  r: number;
  cx: number;
  y: number;
}
interface Pt {
  x: number;
  y: number;
}
interface Sample {
  y: number;
  len: number;
}
interface DrawEl {
  el: SVGGeometryElement;
  len: number;
}
interface OrnBox {
  start: number;
  end: number;
  draw: DrawEl[];
}

/**
 * THE SIGNATURE EFFECT — the page is being tattooed.
 *
 * A single fine SVG line draws itself down the whole page as you scroll,
 * stitching every section together. Section titles and the three ornaments
 * (rose, chess compass, mandala) sit ON the path, so the line writes the words
 * and draws the motifs as it passes. A glowing dot rides the drawing frontier.
 *
 * The critical detail: scroll position is mapped to the *correct length along
 * the weaving path* via a Y→length lookup (the path's length is NOT proportional
 * to page height), so the dot always sits exactly where drawing is happening and
 * stays on screen the whole way down. The dot eases toward the scroll target, so
 * you see it actively drawing rather than teleporting.
 *
 * Under prefers-reduced-motion the line renders once, fully drawn and static,
 * with no dot.
 */
export function NeedleLine({ containerRef }: NeedleLineProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const tipRef = useRef<SVGCircleElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const root = containerRef.current;
    const svg = svgRef.current;
    const path = pathRef.current;
    const tip = tipRef.current;
    if (!root || !svg || !path || !tip) return;

    let L = 0;
    let rootTop = 0;
    let rootH = 0;
    let samples: Sample[] = [];
    let ornBoxes: OrnBox[] = [];
    let drawnLen = 0;
    let targetLen = 0;
    let raf = 0;
    let tickRaf = 0;
    let buildTimer = 0;

    const lenForY = (y: number): number => {
      if (!samples.length) return 0;
      if (y <= samples[0]!.y) return 0;
      const last = samples[samples.length - 1]!;
      if (y >= last.y) return last.len;
      let lo = 0;
      let hi = samples.length - 1;
      while (lo < hi) {
        const m = (lo + hi) >> 1;
        if (samples[m]!.y < y) lo = m + 1;
        else hi = m;
      }
      const a = samples[Math.max(0, lo - 1)]!;
      const b = samples[lo]!;
      const span = b.y - a.y || 1;
      return a.len + ((b.len - a.len) * (y - a.y)) / span;
    };

    const initOrnaments = () => {
      root.querySelectorAll<HTMLElement>("[data-ornament]").forEach((box) => {
        const draw = Array.from(box.querySelectorAll<SVGGeometryElement>("[data-draw]")).map((el) => {
          const len =
            el.tagName.toLowerCase() === "circle"
              ? 2 * Math.PI * parseFloat(el.getAttribute("r") || "0")
              : el.getTotalLength();
          el.style.strokeDasharray = String(len);
          el.style.strokeDashoffset = String(reduced ? 0 : len);
          return { el, len };
        });
        (box as HTMLElement & { __draw?: DrawEl[] }).__draw = draw;
      });
    };

    const drawOrnaments = (y: number) => {
      for (const o of ornBoxes) {
        const span = o.end - o.start || 1;
        const local = Math.max(0, Math.min(1, (y - o.start) / span));
        const n = o.draw.length;
        for (let i = 0; i < n; i++) {
          let t = (local - (i / n) * 0.5) / 0.5;
          t = Math.max(0, Math.min(1, t));
          const e = 1 - Math.pow(1 - t, 3);
          o.draw[i]!.el.style.strokeDashoffset = String(o.draw[i]!.len * (1 - e));
        }
      }
    };

    const renderFrontier = () => {
      if (reduced || !L) return;
      const len = Math.max(0, Math.min(L, drawnLen));
      path.style.strokeDashoffset = String(L - len);
      let dotY = 0;
      if (len > 1 && len < L - 1) {
        const pt = path.getPointAtLength(len);
        dotY = pt.y;
        tip.setAttribute("cx", String(pt.x));
        tip.setAttribute("cy", String(pt.y));
        tip.setAttribute("opacity", "1");
      } else {
        tip.setAttribute("opacity", "0");
      }
      drawOrnaments(dotY);
    };

    const tick = () => {
      const diff = targetLen - drawnLen;
      if (Math.abs(diff) < 0.5) {
        drawnLen = targetLen;
        tickRaf = 0;
        renderFrontier();
        return;
      }
      drawnLen += diff * 0.09; // ease — this is what makes the dot visibly draw
      renderFrontier();
      tickRaf = requestAnimationFrame(tick);
    };

    const syncTarget = () => {
      if (reduced || !rootH) return;
      const targetY = Math.max(0, Math.min(rootH, window.scrollY + window.innerHeight * 0.72 - rootTop));
      targetLen = lenForY(targetY);
      if (!tickRaf) tickRaf = requestAnimationFrame(tick);
    };

    const build = () => {
      const rr = root.getBoundingClientRect();
      const w = root.clientWidth;
      const h = root.scrollHeight;
      if (!w || !h) return;
      svg.setAttribute("width", String(w));
      svg.setAttribute("height", String(h));
      svg.style.height = `${h}px`;

      initOrnaments();

      const anchors: Anchor[] = Array.from(root.querySelectorAll<HTMLElement>("[data-needle],[data-ornament]"))
        .filter((el) => el.offsetParent !== null)
        .map((el) => {
          const r = el.getBoundingClientRect();
          return {
            orn: el.hasAttribute("data-ornament"),
            ink: el.hasAttribute("data-ink"),
            l: r.left - rr.left,
            r: r.right - rr.left,
            cx: (r.left + r.right) / 2 - rr.left,
            y: r.top - rr.top + r.height / 2,
          };
        })
        .sort((a, b) => a.y - b.y);
      if (!anchors.length) return;

      const pts: Pt[] = [];
      anchors.forEach((a, i) => {
        if (i > 0) pts.push({ x: i % 2 === 0 ? w * 0.24 : w * 0.76, y: (anchors[i - 1]!.y + a.y) / 2 });
        if (a.ink) {
          // route ACROSS the heading, left to right, so the needle writes the words
          pts.push({ x: Math.max(a.l - 26, 12), y: a.y });
          pts.push({ x: Math.min(a.r + 20, w - 12), y: a.y });
        } else {
          pts.push({ x: a.orn ? a.cx : i % 2 === 0 ? Math.min(a.r + 44, w - 16) : Math.max(a.l - 44, 16), y: a.y });
        }
      });
      const last = anchors[anchors.length - 1]!;
      pts.push({ x: Math.min(last.cx, w - 20), y: last.y + 60 });

      let px = w * 0.62;
      let py = Math.max(0, anchors[0]!.y - 300);
      let d = `M ${px.toFixed(1)} ${py.toFixed(1)}`;
      for (const p of pts) {
        const my = (py + p.y) / 2;
        d += ` C ${px.toFixed(1)} ${my.toFixed(1)}, ${p.x.toFixed(1)} ${my.toFixed(1)}, ${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
        px = p.x;
        py = p.y;
      }
      path.setAttribute("d", d);

      L = path.getTotalLength();
      rootTop = rr.top + window.scrollY;
      rootH = h;

      const N = 600;
      samples = new Array(N + 1);
      for (let i = 0; i <= N; i++) {
        const len = (L * i) / N;
        const p = path.getPointAtLength(len);
        samples[i] = { y: p.y, len };
      }

      ornBoxes = Array.from(root.querySelectorAll<HTMLElement>("[data-ornament]")).map((box) => {
        const r = box.getBoundingClientRect();
        const cy = r.top - rr.top + r.height / 2;
        return {
          start: cy - r.height * 0.5,
          end: cy + r.height * 0.15,
          draw: (box as HTMLElement & { __draw?: DrawEl[] }).__draw || [],
        };
      });

      if (reduced) {
        path.style.strokeDasharray = "";
        path.style.strokeDashoffset = "";
        tip.setAttribute("opacity", "0");
        // reduced: leave ornaments fully drawn (offset already 0)
      } else {
        path.style.strokeDasharray = String(L);
        syncTarget();
        renderFrontier();
      }
    };

    const scheduleBuild = () => {
      window.clearTimeout(buildTimer);
      buildTimer = window.setTimeout(build, 140);
    };

    const onScroll = () => {
      syncTarget();
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
      });
    };

    const onResize = () => scheduleBuild();

    // initial build (wait a frame for layout, then again after fonts settle)
    requestAnimationFrame(build);
    if (document.fonts?.ready) document.fonts.ready.then(scheduleBuild).catch(() => {});
    const settle = window.setTimeout(scheduleBuild, 900);

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize);
    const ro = new ResizeObserver(scheduleBuild);
    ro.observe(root);

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      ro.disconnect();
      window.clearTimeout(buildTimer);
      window.clearTimeout(settle);
      if (raf) cancelAnimationFrame(raf);
      if (tickRaf) cancelAnimationFrame(tickRaf);
    };
  }, [containerRef, reduced]);

  return (
    <svg
      ref={svgRef}
      aria-hidden="true"
      className="pointer-events-none absolute left-0 top-0 z-40 w-full"
      style={{ overflow: "visible" }}
    >
      <path ref={pathRef} d="" fill="none" stroke="var(--accent)" strokeWidth={1.8} strokeLinecap="round" opacity={0.82} />
      <circle
        ref={tipRef}
        r={5.5}
        fill="#e05a5a"
        opacity={0}
        style={{ filter: "drop-shadow(0 0 8px rgba(224,90,90,.95))" }}
      />
    </svg>
  );
}
