"use client";

import { type ReactNode, useState } from "react";
import { useLanguage } from "@/context/LanguageProvider";
import { BUDGET_OPTIONS, CONTACT, STYLE_OPTIONS } from "@/lib/content";
import type { MessageKey } from "@/lib/i18n";
import { InkButton } from "@/components/ui/InkButton";
import { InkedHeading } from "@/components/motion/InkedHeading";

type Errors = Partial<Record<"name" | "email" | "idea", MessageKey>>;

const inputClass =
  "w-full box-border border border-ink/[0.12] bg-panel px-3.5 py-[13px] text-[15px] text-ink outline-none";

/** Field shell with the accent underline that "draws" itself on focus. */
function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="group flex flex-col gap-2">
      <label htmlFor={htmlFor} className="text-[11px] uppercase tracking-label text-ink/55">
        {label}
      </label>
      <div className="relative">
        {children}
        <span
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 h-0.5 origin-left scale-x-0 bg-accent transition-transform duration-[450ms] ease-ink group-focus-within:scale-x-100"
        />
      </div>
      <span role="alert" className="min-h-[15px] text-xs text-accent-error">
        {error ?? ""}
      </span>
    </div>
  );
}

export function Booking() {
  const { t } = useLanguage();
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState(false);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const val = (k: string) => String(fd.get(k) ?? "").trim();

    const next: Errors = {};
    if (!val("name")) next.name = "errReq";
    const email = val("email");
    if (!email) next.email = "errReq";
    else if (!/^\S+@\S+\.\S+$/.test(email)) next.email = "errEmail";
    if (!val("idea")) next.idea = "errReq";

    if (Object.keys(next).length) {
      setErrors(next);
      setSent(false);
      const firstKey = next.name ? "name" : next.email ? "email" : "idea";
      form.querySelector<HTMLElement>(`[name=${firstKey}]`)?.focus();
      return;
    }

    setErrors({});
    setSent(true);
    const lines = [
      `Name: ${val("name")}`,
      `Email: ${email}`,
      `Placement: ${val("placement")}`,
      `Size: ${val("size")}`,
      `Style: ${val("style")}`,
      `Budget: ${val("budget")}`,
      `Availability: ${val("availability")}`,
      "",
      "Idea:",
      val("idea"),
      "",
      "(Reference images attached)",
    ];
    const href =
      `mailto:${CONTACT.email}?subject=` +
      encodeURIComponent(`Booking inquiry — ${val("name")}`) +
      "&body=" +
      encodeURIComponent(lines.join("\n"));
    window.location.href = href;
  };

  return (
    <section id="book" className="relative z-[1] mx-auto box-border max-w-[900px] scroll-mt-[70px] px-[clamp(20px,5vw,72px)] pb-[90px] pt-[110px]">
      <span className="block text-[11px] uppercase tracking-kicker text-accent-bright">{t("bookK")}</span>
      <InkedHeading id="book-title" className="mt-3.5 text-[clamp(44px,7vw,84px)] leading-none">
        {t("bookT")}
      </InkedHeading>
      <p className="mt-[22px] max-w-[52ch] text-base leading-[1.7] text-ink/70">{t("bookSub")}</p>

      <form noValidate onSubmit={onSubmit} className="mt-[42px] grid grid-cols-[repeat(auto-fit,minmax(240px,1fr))] gap-x-[26px] gap-y-[22px]">
        <Field label={t("lName")} htmlFor="f-name" error={errors.name ? t(errors.name) : undefined}>
          <input id="f-name" name="name" autoComplete="name" placeholder={t("phName")} className={inputClass} />
        </Field>

        <Field label={t("lEmail")} htmlFor="f-email" error={errors.email ? t(errors.email) : undefined}>
          <input id="f-email" name="email" type="email" autoComplete="email" placeholder="you@example.com" className={inputClass} />
        </Field>

        <Field label={t("lPlacement")} htmlFor="f-placement">
          <input id="f-placement" name="placement" placeholder={t("phPlacement")} className={inputClass} />
        </Field>

        <Field label={t("lSize")} htmlFor="f-size">
          <input id="f-size" name="size" placeholder={t("phSize")} className={inputClass} />
        </Field>

        <Field label={t("lStyle")} htmlFor="f-style">
          <select id="f-style" name="style" className={`${inputClass} cursor-pointer appearance-none`} defaultValue="Fine line">
            {STYLE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {t(o.key as MessageKey)}
              </option>
            ))}
          </select>
        </Field>

        <Field label={t("lBudget")} htmlFor="f-budget">
          <select id="f-budget" name="budget" className={`${inputClass} cursor-pointer appearance-none`} defaultValue="€200–€400">
            {BUDGET_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.key ? t(o.key as MessageKey) : o.label}
              </option>
            ))}
          </select>
        </Field>

        <div className="col-span-full">
          <Field label={t("lAvail")} htmlFor="f-avail">
            <input id="f-avail" name="availability" placeholder={t("phAvail")} className={inputClass} />
          </Field>
        </div>

        <div className="col-span-full">
          <Field label={t("lIdea")} htmlFor="f-idea" error={errors.idea ? t(errors.idea) : undefined}>
            <textarea id="f-idea" name="idea" rows={5} placeholder={t("phIdea")} className={`${inputClass} resize-y font-sans`} />
          </Field>
        </div>

        <div data-needle className="col-span-full mt-1.5 flex flex-wrap items-center gap-[18px]">
          <InkButton type="submit" size="lg">
            {t("submit")}
          </InkButton>
          <span className="max-w-[38ch] text-[13px] text-ink/45">{t("bookNote")}</span>
        </div>

        <p role="status" className="col-span-full m-0 min-h-[18px] text-sm italic text-ink">
          {sent ? t("sentNote") : ""}
        </p>
      </form>

      <p className="mt-3.5 text-sm text-ink/60">
        <span className="tracking-[0.05em]">{t("bookDm")}</span>
        <a href={CONTACT.instagram.url} target="_blank" rel="noopener" className="ml-3 text-accent-bright hover:text-accent-bright">
          Instagram
        </a>
        <span aria-hidden="true" className="mx-2 text-ink/30">
          ·
        </span>
        <a href={CONTACT.telegram.url} target="_blank" rel="noopener" className="text-accent-bright hover:text-accent-bright">
          Telegram
        </a>
      </p>
    </section>
  );
}
