"use client";

import { useId, useState } from "react";
import { useLanguage } from "@/context/LanguageProvider";
import { FAQ } from "@/lib/content";
import type { MessageKey } from "@/lib/i18n";
import { InkedHeading } from "@/components/motion/InkedHeading";

export function Faq() {
  const { t } = useLanguage();
  const [open, setOpen] = useState<number | null>(null);
  const base = useId();

  return (
    <section id="faq" className="relative z-[1] mx-auto box-border max-w-[860px] scroll-mt-[70px] px-[clamp(20px,5vw,72px)] py-[110px]">
      <span className="block text-[11px] uppercase tracking-kicker text-accent-bright">{t("faqK")}</span>
      <InkedHeading id="faq-title" className="mb-[34px] mt-3.5 text-[clamp(40px,6vw,76px)] leading-none">
        {t("faqT")}
      </InkedHeading>

      <div className="border-t border-ink/10">
        {FAQ.map((entry, i) => {
          const isOpen = open === i;
          const panelId = `${base}-faq-${i}`;
          return (
            <div key={entry.questionKey} className={`border-b border-ink/10`}>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full cursor-pointer items-center justify-between gap-4 bg-transparent py-[22px] text-left text-[17px] font-medium text-ink"
              >
                <span>{t(entry.questionKey as MessageKey)}</span>
                <span
                  aria-hidden="true"
                  className="font-display text-2xl leading-none text-accent transition-transform duration-[350ms]"
                  style={{ transform: isOpen ? "rotate(45deg)" : undefined }}
                >
                  +
                </span>
              </button>
              <div
                id={panelId}
                role="region"
                className="grid transition-[grid-template-rows] duration-[450ms] ease-ink"
                style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
              >
                <div className="overflow-hidden">
                  <p className="mb-[26px] max-w-[62ch] text-[15px] leading-[1.75] text-ink/65">
                    {t(entry.answerKey as MessageKey)}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
