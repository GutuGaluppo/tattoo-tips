"use client";

import { useMemo, useState } from "react";
import { useLanguage } from "@/context/LanguageProvider";
import { FILTERS, PORTFOLIO } from "@/lib/content";
import type { PortfolioItem } from "@/lib/types";
import type { MessageKey } from "@/lib/i18n";
import { InkedHeading } from "@/components/motion/InkedHeading";
import { StencilImage } from "@/components/motion/StencilImage";
import { Lightbox, type LightboxItem } from "@/components/ui/Lightbox";

type Filter = (typeof FILTERS)[number]["value"];

export function Portfolio() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<Filter>("all");
  const [active, setActive] = useState<LightboxItem | null>(null);

  const items = useMemo(
    () => (filter === "all" ? PORTFOLIO : PORTFOLIO.filter((p) => p.category === filter)),
    [filter],
  );

  const open = (item: PortfolioItem) =>
    setActive({
      src: item.src,
      alt: `${item.title} — ${t(item.catKey)}`,
      title: item.title,
      category: t(item.catKey),
      width: item.width,
      height: item.height,
    });

  return (
    <section id="work" className="relative z-[1] mx-auto box-border max-w-[1280px] scroll-mt-[70px] px-[clamp(20px,5vw,72px)] pb-[70px] pt-[130px]">
      <span className="block text-[11px] uppercase tracking-kicker text-accent-bright">{t("workK")}</span>
      <InkedHeading id="work-title" className="mt-3.5 text-[clamp(44px,7vw,84px)] leading-none">
        {t("workT")}
      </InkedHeading>

      <div role="group" aria-label="Filter portfolio" className="mt-[34px] flex flex-wrap gap-2.5">
        {FILTERS.map((f) => {
          const on = f.value === filter;
          return (
            <button
              key={f.value}
              type="button"
              aria-pressed={on}
              onClick={() => setFilter(f.value)}
              className={`cursor-pointer border px-[18px] py-2 text-xs uppercase tracking-[0.16em] transition-colors ${
                on ? "border-accent bg-accent/[0.18] text-ink" : "border-ink/[0.18] text-ink/65 hover:text-ink"
              }`}
            >
              {t(f.key as MessageKey)}
            </button>
          );
        })}
      </div>

      <div className="mt-11 [column-gap:22px] [columns:3_280px]">
        {items.map((item) => (
          <figure
            key={item.id}
            tabIndex={0}
            role="button"
            aria-label={`${item.title}, ${t(item.catKey)} — open larger view`}
            onClick={() => open(item)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                open(item);
              }
            }}
            className="mb-[22px] block cursor-zoom-in [break-inside:avoid]"
          >
            <StencilImage
              src={item.src}
              alt={`${item.title}, ${t(item.catKey)} tattoo`}
              width={item.width}
              height={item.height}
              sizes="(max-width: 720px) 100vw, (max-width: 1100px) 50vw, 33vw"
              className="w-full"
              style={{ aspectRatio: item.aspect }}
            />
            <figcaption className="mt-2.5 flex items-baseline justify-between gap-3 text-[13px] text-ink/[0.68]">
              <span>{item.title}</span>
              <span className="text-[10px] uppercase tracking-[0.22em] text-ink/40">{t(item.catKey)}</span>
            </figcaption>
          </figure>
        ))}
      </div>

      <Lightbox item={active} onClose={() => setActive(null)} />
    </section>
  );
}
