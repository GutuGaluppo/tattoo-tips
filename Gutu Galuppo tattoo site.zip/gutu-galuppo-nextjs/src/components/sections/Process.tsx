"use client";

import { useLanguage } from "@/context/LanguageProvider";
import { PROCESS } from "@/lib/content";
import type { MessageKey } from "@/lib/i18n";
import { InkedHeading } from "@/components/motion/InkedHeading";

export function Process() {
  const { t } = useLanguage();

  return (
    <section id="process" className="relative z-[1] mx-auto box-border max-w-[1280px] scroll-mt-[70px] px-[clamp(20px,5vw,72px)] py-[110px]">
      <span className="block text-[11px] uppercase tracking-kicker text-accent-bright">{t("procK")}</span>
      <InkedHeading id="process-title" className="mt-3.5 text-[clamp(40px,6vw,76px)] leading-none">
        {t("procT")}
      </InkedHeading>

      <div className="mt-[30px] max-w-[760px]">
        {PROCESS.map((step, i) => (
          <div
            key={step.numeral}
            className={`grid grid-cols-[84px_1fr] gap-[26px] border-t border-ink/[0.09] py-10 ${
              i === PROCESS.length - 1 ? "border-b" : ""
            } ${i === 0 ? "mt-6" : ""}`}
          >
            {/* numeral sits on the needle path — the line threads the steps */}
            <span data-needle aria-hidden="true" className="justify-self-center font-display text-[52px] leading-none text-accent">
              {step.numeral}
            </span>
            <div>
              <h3 className="text-[19px] font-semibold text-ink">{t(step.titleKey as MessageKey)}</h3>
              <p className="mt-2.5 max-w-[54ch] text-[15px] leading-[1.7] text-ink/65">{t(step.bodyKey as MessageKey)}</p>
            </div>
          </div>
        ))}
        <p className="mt-[26px] text-[13.5px] italic text-ink/45">{t("procNote")}</p>
      </div>
    </section>
  );
}
