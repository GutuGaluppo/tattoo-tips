"use client";

import { useLanguage } from "@/context/LanguageProvider";
import { CONTACT } from "@/lib/content";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="relative z-[1] box-border border-t border-ink/[0.09] px-[clamp(20px,5vw,72px)] pb-[46px] pt-16">
      <div className="mx-auto grid max-w-[1280px] grid-cols-[repeat(auto-fit,minmax(220px,1fr))] gap-[38px]">
        <div>
          <span className="font-display text-[34px] leading-none text-ink">Gutu Galuppo</span>
          <p className="mt-3 text-[13.5px] leading-[1.7] text-ink/55">
            {t("ftBased")}
            <br />
            {t("ftLoc")}
          </p>
        </div>

        <div>
          <span className="block text-[11px] uppercase tracking-label text-ink/45">{t("ftHours")}</span>
          <p className="mt-3 text-sm leading-[1.7] text-ink/70">{t("ftHoursV")}</p>
        </div>

        <div className="flex flex-col gap-2.5 text-sm">
          <a href={CONTACT.instagram.url} target="_blank" rel="noopener" className="text-accent-bright hover:text-accent-bright">
            Instagram — {CONTACT.instagram.handle}
          </a>
          <a href={CONTACT.telegram.url} target="_blank" rel="noopener" className="text-ink/80 hover:text-accent-bright">
            Telegram — {CONTACT.telegram.handle}
          </a>
          <a href={`mailto:${CONTACT.email}`} className="text-ink/80 hover:text-accent-bright">
            {CONTACT.email}
          </a>
        </div>
      </div>
      <p className="mx-auto mt-11 max-w-[1280px] text-xs text-ink/35">© 2026 Gutu Galuppo</p>
    </footer>
  );
}
