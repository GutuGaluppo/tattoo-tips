"use client";

import Image from "next/image";
import { useLanguage } from "@/context/LanguageProvider";
import { BLUR_DATA_URL } from "@/lib/content";
import { InkButton } from "@/components/ui/InkButton";
import { InkedHeading } from "@/components/motion/InkedHeading";
import { Parallax } from "@/components/motion/Parallax";

export function Hero() {
  const { t } = useLanguage();

  return (
    <header id="top" className="relative z-[1] flex min-h-[100svh] items-end overflow-hidden">
      {/* layer 1 — background photo (slowest) */}
      <Parallax speed={0.14} className="absolute inset-x-0 -inset-y-[14%] z-0">
        <Image
          src="/portfolio/made-in-brasil.png"
          alt="Fine-line lettering tattoo reading Made in Brasil on a hand"
          fill
          priority
          placeholder="blur"
          blurDataURL={BLUR_DATA_URL}
          sizes="100vw"
          className="object-cover"
          style={{ objectPosition: "50% 30%", filter: "grayscale(.35) brightness(.5) contrast(1.08)" }}
        />
      </Parallax>

      <div
        aria-hidden="true"
        className="absolute inset-0 z-0"
        style={{ background: "linear-gradient(180deg, rgba(10,10,10,.62), rgba(10,10,10,.3) 45%, #0a0a0a 97%)" }}
      />

      {/* layer 3 — ornamental detail (faster) */}
      <Parallax speed={-0.09} className="absolute right-[4%] top-[14%] z-0 h-auto w-[min(32vw,340px)]">
        <svg viewBox="0 0 200 200" aria-hidden="true" className="h-auto w-full opacity-[0.28]">
          <circle cx="100" cy="100" r="96" fill="none" stroke="#ece7df" strokeWidth={0.8} />
          <circle cx="100" cy="100" r="88" fill="none" stroke="#ece7df" strokeWidth={0.8} strokeDasharray="1.5 9" />
          <circle cx="100" cy="100" r="70" fill="none" stroke="#ece7df" strokeWidth={0.6} />
          <circle cx="100" cy="100" r="63" fill="none" stroke="#ece7df" strokeWidth={0.6} strokeDasharray="1 6" />
          <path d="M100 44 L112 100 L100 156 L88 100 Z" fill="none" stroke="#ece7df" strokeWidth={0.8} />
          <circle cx="100" cy="100" r="5" fill="none" stroke="var(--accent)" strokeWidth={1.2} />
        </svg>
      </Parallax>

      {/* layer 2 — title block (normal speed) */}
      <div className="relative z-[1] mx-auto box-border w-full max-w-[1280px] px-[clamp(20px,5vw,72px)] pb-[15vh] pt-[140px]">
        <p className="mb-3.5 text-xs uppercase tracking-kicker text-ink/[0.62]">
          {t("heroKicker")} <span className="text-accent-bright">Berlin</span>
        </p>
        <InkedHeading
          as="h1"
          onNeedle={false}
          className="text-[clamp(66px,13vw,180px)] leading-[.92] tracking-[.01em]"
        >
          Gutu Galuppo
        </InkedHeading>
        <p className="mt-[26px] max-w-[46ch] text-[clamp(15px,1.6vw,18px)] leading-[1.7] text-ink-soft">{t("heroSub")}</p>
        <div className="mt-[38px] flex flex-wrap gap-3.5">
          <InkButton href="#book" size="lg">
            {t("cta")}
          </InkButton>
          <InkButton href="#work" size="lg" variant="ghost">
            {t("heroCta2")}
          </InkButton>
        </div>
      </div>

      <div aria-hidden="true" className="absolute bottom-[22px] left-1/2 z-[1] flex -translate-x-1/2 flex-col items-center gap-2.5">
        <span className="text-[10.5px] uppercase tracking-[.3em] text-ink/45">{t("heroScroll")}</span>
        <span className="h-[42px] w-px" style={{ background: "linear-gradient(180deg, var(--accent), transparent)" }} />
      </div>
    </header>
  );
}
