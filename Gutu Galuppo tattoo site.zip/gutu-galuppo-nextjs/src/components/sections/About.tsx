"use client";

import Image from "next/image";
import { useLanguage } from "@/context/LanguageProvider";
import { BLUR_DATA_URL } from "@/lib/content";
import { InkedHeading } from "@/components/motion/InkedHeading";
import { Parallax } from "@/components/motion/Parallax";

export function About() {
  const { t } = useLanguage();

  return (
    <section
      id="about"
      className="relative z-[1] mx-auto box-border grid max-w-[1280px] scroll-mt-[70px] grid-cols-[repeat(auto-fit,minmax(300px,1fr))] items-center gap-[clamp(36px,6vw,96px)] px-[clamp(20px,5vw,72px)] py-[110px]"
    >
      <div className="overflow-hidden">
        <Parallax speed={-0.05} className="aspect-[4/5]">
          <Image
            src="https://placehold.co/900x1125/141312/5f5b55?text=Portrait"
            alt="Portrait of Gutu Galuppo at work"
            width={900}
            height={1125}
            placeholder="blur"
            blurDataURL={BLUR_DATA_URL}
            sizes="(max-width: 720px) 100vw, 40vw"
            className="h-full w-full object-cover"
            style={{ filter: "grayscale(1) contrast(1.05)" }}
          />
        </Parallax>
      </div>

      <div>
        <span className="block text-[11px] uppercase tracking-kicker text-accent-bright">{t("aboutK")}</span>
        <InkedHeading id="about-title" className="mt-3.5 text-[clamp(40px,5.5vw,68px)] leading-none">
          {t("aboutT")}
        </InkedHeading>
        <p className="mt-7 max-w-[56ch] text-base leading-[1.8] text-ink/75">{t("aboutB1")}</p>
        <p className="mt-5 max-w-[56ch] text-base italic leading-[1.8] text-ink/55">{t("aboutB2")}</p>
      </div>
    </section>
  );
}
