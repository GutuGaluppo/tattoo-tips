export type Category = "blackwork" | "fineline" | "ornamental";

export interface PortfolioItem {
  /** stable id — also the drop-in filename stem under /public/portfolio */
  id: string;
  title: string;
  category: Category;
  /** i18n key for the category label */
  catKey: "fBlack" | "fFine" | "fOrn";
  src: string;
  width: number;
  height: number;
  /** CSS aspect-ratio string, e.g. "3 / 4" — drives the masonry cell */
  aspect: string;
}

export interface ProcessStep {
  numeral: string;
  titleKey: string;
  bodyKey: string;
}

export interface FaqEntry {
  questionKey: string;
  answerKey: string;
}

export type OrnamentKind = "rose" | "chess" | "mandala";
