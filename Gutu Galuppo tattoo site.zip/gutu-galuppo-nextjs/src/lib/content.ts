import type { FaqEntry, PortfolioItem, ProcessStep } from "./types";

/**
 * Contact + studio details in one place.
 */
export const CONTACT = {
  instagram: { handle: "@gutu_ink", url: "https://www.instagram.com/gutu_ink/" },
  telegram: { handle: "@GaluppoGutu", url: "https://t.me/GaluppoGutu" },
  email: "galuppodev@gmail.com",
  city: "Berlin",
} as const;

/**
 * A shared blur placeholder (tiny near-black gradient) used by next/image while
 * the real photo loads.
 */
export const BLUR_DATA_URL =
  "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+PHJlY3Qgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiBmaWxsPSIjMTQxMzEyIi8+PC9zdmc+";

/**
 * Portfolio grid. `src` points at placehold.co for the seed; drop a real photo
 * at /public/portfolio/<id>.jpg and change `src` to `/portfolio/<id>.jpg`.
 * The first piece ships with the artist's real reference image.
 */
export const PORTFOLIO: PortfolioItem[] = [
  { id: "made-in-brasil", title: "Made in Brasil", category: "fineline", catKey: "fFine", src: "/portfolio/made-in-brasil.png", width: 900, height: 1200, aspect: "3 / 4" },
  { id: "carranca", title: "Carranca", category: "blackwork", catKey: "fBlack", src: ph(800, 1200, "Carranca"), width: 800, height: 1200, aspect: "2 / 3" },
  { id: "renda-de-bilro", title: "Renda de bilro", category: "ornamental", catKey: "fOrn", src: ph(900, 1200, "Renda+de+bilro"), width: 900, height: 1200, aspect: "3 / 4" },
  { id: "bem-te-vi", title: "Bem-te-vi", category: "fineline", catKey: "fFine", src: ph(1000, 1000, "Bem-te-vi"), width: 1000, height: 1000, aspect: "1 / 1" },
  { id: "xilogravura", title: "Xilogravura", category: "blackwork", catKey: "fBlack", src: ph(900, 1200, "Xilogravura"), width: 900, height: 1200, aspect: "3 / 4" },
  { id: "mandala-do-sertao", title: "Mandala do sertão", category: "ornamental", catKey: "fOrn", src: ph(800, 1200, "Mandala+do+sert%C3%A3o"), width: 800, height: 1200, aspect: "2 / 3" },
  { id: "fita-do-bonfim", title: "Fita do Bonfim", category: "fineline", catKey: "fFine", src: ph(900, 1200, "Fita+do+Bonfim"), width: 900, height: 1200, aspect: "3 / 4" },
  { id: "mata-fechada", title: "Mata fechada", category: "blackwork", catKey: "fBlack", src: ph(1000, 1000, "Mata+fechada"), width: 1000, height: 1000, aspect: "1 / 1" },
  { id: "sol-e-lua", title: "Sol e lua", category: "ornamental", catKey: "fOrn", src: ph(900, 1200, "Sol+e+lua"), width: 900, height: 1200, aspect: "3 / 4" },
  { id: "samambaia", title: "Samambaia", category: "fineline", catKey: "fFine", src: ph(800, 1200, "Samambaia"), width: 800, height: 1200, aspect: "2 / 3" },
  { id: "serpente-dagua", title: "Serpente d'água", category: "blackwork", catKey: "fBlack", src: ph(900, 1200, "Serpente+d%27%C3%A1gua"), width: 900, height: 1200, aspect: "3 / 4" },
  { id: "espinha-de-peixe", title: "Espinha de peixe", category: "ornamental", catKey: "fOrn", src: ph(1000, 1000, "Espinha+de+peixe"), width: 1000, height: 1000, aspect: "1 / 1" },
];

function ph(w: number, h: number, label: string): string {
  return `https://placehold.co/${w}x${h}/141312/5f5b55?text=${label}`;
}

export const FILTERS: { value: "all" | PortfolioItem["category"]; key: string }[] = [
  { value: "all", key: "fAll" },
  { value: "blackwork", key: "fBlack" },
  { value: "fineline", key: "fFine" },
  { value: "ornamental", key: "fOrn" },
];

export const PROCESS: ProcessStep[] = [
  { numeral: "I", titleKey: "p1t", bodyKey: "p1d" },
  { numeral: "II", titleKey: "p2t", bodyKey: "p2d" },
  { numeral: "III", titleKey: "p3t", bodyKey: "p3d" },
  { numeral: "IV", titleKey: "p4t", bodyKey: "p4d" },
];

export const FAQ: FaqEntry[] = [
  { questionKey: "q1", answerKey: "a1" },
  { questionKey: "q2", answerKey: "a2" },
  { questionKey: "q3", answerKey: "a3" },
  { questionKey: "q4", answerKey: "a4" },
  { questionKey: "q5", answerKey: "a5" },
];

export const STYLE_OPTIONS = [
  { value: "Fine line", key: "sFine" },
  { value: "Blackwork", key: "sBlack" },
  { value: "Ornamental", key: "sOrn" },
  { value: "Not sure yet", key: "sUnsure" },
];

interface BudgetOption {
  value: string;
  label: string;
  /** i18n key, when the label should be translated */
  key?: string;
}

export const BUDGET_OPTIONS: BudgetOption[] = [
  { value: "Up to €200", label: "Up to €200" },
  { value: "€200–€400", label: "€200–€400" },
  { value: "€400–€800", label: "€400–€800" },
  { value: "€800+", label: "€800+" },
  { value: "Not sure", key: "bUnsure", label: "Not sure" },
];
